#!/bin/bash

condor_submit_dag submit.dag
