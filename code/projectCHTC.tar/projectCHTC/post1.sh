#!/bin/bash

cat *movie.txt | sort -t ' ' -k 1n | uniq > movieYear.txt
cat *short.txt | sort -t ' ' -k 1n | uniq > shortYear.txt
cat *tvEpisode.txt | sort -t ' ' -k 1n | uniq > tvEpisodeYear.txt
cat *tvMiniSeries.txt | sort -t ' ' -k 1n | uniq > tvMiniSeriesYear.txt
cat *tvMovie.txt | sort -t ' ' -k 1n | uniq > tvMovieYear.txt
cat *tvSeries.txt | sort -t ' ' -k 1n | uniq > tvSeriesYear.txt
cat *tvShort.txt | sort -t ' ' -k 1n |uniq > tvShortYear.txt
cat *tvSpecial.txt | sort -t ' ' -k 1n | uniq > tvSpecialYear.txt
cat *video.txt | sort -t ' ' -k 1n | uniq > videoYear.txt
cat *videoGame.txt | sort -t ' ' -k 1n |uniq > videoGameYear.txt

mkdir TopProduction

mv movie1*.txt TopProduction/
mv short1*.txt TopProduction/
mv tvEpisode1*.txt TopProduction/
mv tvMiniSeries1*.txt TopProduction/
mv tvMovie1*.txt TopProduction/
mv tvSeries1*.txt TopProduction/
mv tvShort1*.txt TopProduction/
mv tvSpecial1*.txt TopProduction/
mv video1*.txt TopProduction/
mv videoGame1*.txt TopProduction/

mv movie2*.txt TopProduction/
mv short2*.txt TopProduction/
mv tvEpisode2*.txt TopProduction/
mv tvMiniSeries2*.txt TopProduction/
mv tvMovie2*.txt TopProduction/
mv tvSeries2*.txt TopProduction/
mv tvShort2*.txt TopProduction/
mv tvSpecial2*.txt TopProduction/
mv video2*.txt TopProduction/
mv videoGame2*.txt TopProduction/

rm -f 1*.txt 2*.txt

mkdir Year
mv *Year.txt Year/

 
