#!/bin/bash

#wget https://datasets.imdbws.com/title.basics.tsv.gz
#wget https://datasets.imdbws.com/title.ratings.tsv.gz


#gzip -d title.basics.tsv.gz
#gzip -d title.ratings.tsv.gz

wget http://datasets.imdbws.com/name.basics.tsv.gz
wget http://datasets.imdbws.com/title.akas.tsv.gz
wget http://datasets.imdbws.com/title.basics.tsv.gz
wget http://datasets.imdbws.com/title.crew.tsv.gz
wget http://datasets.imdbws.com/title.episode.tsv.gz
wget http://datasets.imdbws.com/title.principals.tsv.gz
wget http://datasets.imdbws.com/title.ratings.tsv.gz

gzip -d name.basics.tsv.gz
gzip -d title.akas.tsv.gz
gzip -d title.basics.tsv.gz
gzip -d title.crew.tsv.gz
gzip -d title.episode.tsv.gz
gzip -d title.principals.tsv.gz
gzip -d title.ratings.tsv.gz


cat title.basics.tsv | cut -d$'\t' -f1,2,3,6 | sort -t$'\t' -k 1,1 | uniq > basics.tsv
# cat title.basics.csv | cut -d, -f1,2,3,6 | sort -t , -k 1,1 > basics.csv
cat title.ratings.tsv | sort -t$'\t' -k 1,1 | uniq > ratings.tsv
join -t$'\t' -1 1 -2 1 basics.tsv ratings.tsv > type_year.tsv

cat type_year.tsv | tail -n +2 | cut -d$'\t' -f2,4 | sort | uniq > list.tsv
cat list.tsv | tr "\\t" "," | awk -F, '{ if ($2 != "\\N") {print $0} }' > list.txt

rm -f list.tsv basics.tsv ratings.tsv
