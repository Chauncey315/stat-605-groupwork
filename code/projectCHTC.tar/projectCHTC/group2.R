rm(list=ls())

args = (commandArgs(trailingOnly=TRUE))
if(length(args) == 2){
  type = args[1]
  dict = args[2]
} else {
  cat('usage: Rscript hw4.R <template spectrum> <data directory>\n', file=stderr())
  stop()
}
data=read.table(dict, fill=T,sep=",",quote="",stringsAsFactors = F,row.names=NULL)
data=data[-1,]
data=data[,c(1, 2, 3, 4, 5)]

names(data)=c("tconst","averageRating","numVotes","titleType","primaryTitle")
data[is.na(data)] <- 0
#data$tconst = as.character(data$tconst)
data=data[nchar(data$tconst)==9,]
data$averageRating = as.numeric(data$averageRating)
data$numVotes = as.numeric(data$numVotes)



len = length(data$tconst)
num = 0
score = 0
name = "no_exsit"
for(i in 1:len){
  d = data[i,]
  if(d$titleType != type || d$numVotes < 800){next}
  if(as.numeric(d$averageRating) > score){
    score = d$averageRating
    num = d$numVotes
    name = d$primaryTitle
  }
}
df = data.frame(titleType = type, Title = name, numVotes = num, ratings = score)
write.table(df,paste("best",type,".csv",sep=""),col.names=F,append = T,sep = ",",quote=F)
          
