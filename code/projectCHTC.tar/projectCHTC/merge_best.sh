#!/bin/bash                                                                     
echo "number,type,title,numVotes,averageRatings" >> best.csv
cat best*.csv >> best.csv

rm -f merge_br.csv
rm -f bestm*.csv bestvi*.csv besttv*.csv bestsh*.csv
