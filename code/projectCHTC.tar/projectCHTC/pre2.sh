#!/bin/bash                                                                     

#wget http://datasets.imdbws.com/name.basics.tsv.gz
#wget http://datasets.imdbws.com/title.akas.tsv.gz
#wget http://datasets.imdbws.com/title.basics.tsv.gz
#wget http://datasets.imdbws.com/title.crew.tsv.gz
#wget http://datasets.imdbws.com/title.episode.tsv.gz
#wget http://datasets.imdbws.com/title.principals.tsv.gz
#wget http://datasets.imdbws.com/title.ratings.tsv.gz

#gzip -d name.basics.tsv.gz
#gzip -d title.akas.tsv.gz
#gzip -d title.basics.tsv.gz
#gzip -d title.crew.tsv.gz
#gzip -d title.episode.tsv.gz
#gzip -d title.principals.tsv.gz
#gzip -d title.ratings.tsv.gz

cat name.basics.tsv | tr "\\t" "," > name.basics.csv
cat title.akas.tsv | tr "\\t" "," > title.akas.csv
cat title.basics.tsv | tr "\\t" "," > title.basics.csv
cat title.crew.tsv | tr "\\t" "," > title.crew.csv
cat title.episode.tsv | tr "\\t" "," > title.episode.csv
cat title.principals.tsv | tr "\\t" "," > title.principals.csv
cat title.ratings.tsv | tr "\\t" "," > title.ratings.csv

cat title.basics.csv | tail -n +2 | cut -d, -f2 | awk '!a[$0]++' | head -n 20 > type.txt

sort -t , -k 1,1 title.basics.csv > basics_sort.csv
sort -t , -k 1,1 title.ratings.csv > ratings_sort.csv
join -t , -1 1 -2 1 ratings_sort.csv basics_sort.csv > merge_br.csv

rm -f basics_sort.csv ratings_sort.csv
#rm -f *.tsv
