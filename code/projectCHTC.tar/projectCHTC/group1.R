rm(list=ls())

args = (commandArgs(trailingOnly=TRUE))
if(length(args) == 2){
  type = args[1]
  year = args[2]
} else {
  cat('usage: Rscript group1.R <type> <year>\n', file=stderr())
  stop()
}

data=read.table('type_year.tsv', header=T, sep="\t",fill=T,quote="")
select1=data[data[,2]==type,]
select=select1[select1[,4]==year,]
#select3=select2[,-2]
#select=select3[,-3]

rating=round(mean(select[,5]),2)
vote=round(mean(select[,6]),2)
index=sort(select[,5],decreasing = T, index.return = T)$ix

n=length(index)
if (n<5) {
   top5=select[index,]
}else {
   ind=index[1:5]
   top5=select[ind,]}

#top5=select[index,]

num=c(year,rating,vote)
names(num)=c("year","AveRating","AveVoting")
mynum=rbind(num,num)

write.table(mynum,paste(year,type,".txt",sep=""),row.names=F,col.names=F, quote=F,sep=" ")
write.table(top5,paste(type,year,".txt",sep=""),row.names=F,quote=F,sep=",")

