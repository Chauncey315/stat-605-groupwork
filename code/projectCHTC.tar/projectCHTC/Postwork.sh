#!/bin/bash
echo "nconst AveRating primaryName" >> Actor10.txt
cat actorRes.txt | tail -n +2 | sort -t ' ' -k 2nr >> Actor10.txt

echo "nconst AveRating primaryName" >> Actress10.txt
cat actressRes.txt | tail -n +2 | sort -t ' ' -k 2nr >> Actress10.txt

echo "nconst AveRating primaryName" >> Composer10.txt
cat composerRes.txt | tail -n +2 | sort -t ' ' -k 2nr >> Composer10.txt

echo "nconst AveRating primaryName" >> Director10.txt
cat directorRes.txt | tail -n +2 | sort -t ' ' -k 2nr >> Director10.txt

echo "nconst AveRating primaryName" >> Producer10.txt
cat producerRes.txt | tail -n +2 | sort -t ' ' -k 2nr >> Producer10.txt

rm -f actorRes.txt actressRes.txt composerRes.txt directorRes.txt producerRes.txt
rm -f director.csv producer.csv actor.csv composer.csv actress.csv ratings.csv people.csv title.csv
rm -f rate1*.txt rate2*.txt rate3*.txt Top10*.txt

mkdir TopPeople
mv *10.txt TopPeople/
mv rate*.txt TopPeople/
