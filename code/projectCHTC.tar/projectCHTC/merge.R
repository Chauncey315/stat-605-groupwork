rm(list=ls())

args = (commandArgs(trailingOnly=TRUE))
if(length(args) == 2){
  a = args[1]
  b = args[2]
} else {
  cat('usage: Rscript merge.R <a> <b>\n', file=stderr())
  stop()
}

data1=read.csv(paste(a,".csv",sep=""),header = T)

data2=read.csv(paste(b,".csv",sep=""), header = T)

#people=read.csv("people.csv", header = T)
title=read.csv("title.csv", header = T)

res=merge(data1,data2,by="tconst",all=F)
res1=merge(res,title[,1:2],by="tconst",all=F)
# numVoting > 800
result1=res1[res1[,4]>800,]
result=result1[result1[,5]=="movie",1:4]

list=sort(table(result[,2]),decreasing = T)
mylist=list[list>2]
choose=names(mylist)
m=length(choose)
n=dim(result)[1]
index=seq(1,n)
ch=NA
for (i in 1:m){
  ind=index[result[,2]==choose[i]]
  ch=c(ch,ind)
}
ch=ch[-1]
result=result[ch,]

#write.table(result,paste(a,"2.txt",sep=""))

myresult=round(tapply(result[,3],result[,2],mean,na.rm=T),2)

#write.table(myresult,paste(a,"2.txt",sep=""))
Top10=sort(myresult, decreasing = T)[1:10]
Top3=sort(myresult, decreasing = T)[1:3]
id=row.names(Top3)
rate1=result[result[,2]==id[1],]
rate2=result[result[,2]==id[2],]
rate3=result[result[,2]==id[3],]

#rate1=merge(rate1,title,by="tconst",all=F)
#rate1=merge(rate1,people, by="nconst",all=F)
#rate2=merge(rate2,title,by="tconst",all=F)
#rate2=merge(rate2,people, by="nconst",all=F)
#rate3=merge(rate3,title,by="tconst",all=F)
#rate3=merge(rate3,people, by="nconst",all=F)

write.table(rate1,paste("rate1",a,".txt",sep=""),quote=F,row.names=F)
write.table(rate2,paste("rate2",a,".txt",sep=""),quote=F,row.names=F)
write.table(rate3,paste("rate3",a,".txt",sep=""),quote=F,row.names=F)

write.table(Top10,paste("Top10",a,".txt",sep=""), quote=F,col.names=F)




