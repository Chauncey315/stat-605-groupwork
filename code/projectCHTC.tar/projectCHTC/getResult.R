rm(list=ls())

args = (commandArgs(trailingOnly=TRUE))
if(length(args) == 2){
  a = args[1]
  b = args[2]
} else {
  cat('usage: Rscript merge.R <a> <b>\n', file=stderr())
  stop()
}

com=read.table(paste("Top10",a,".txt",sep=""),header=F,sep=" ")
colnames(com)=c("nconst","AveRating")
people=read.csv(paste(b,".csv",sep=""),header=T)
Com=merge(com,people,by="nconst",all=F)
write.table(Com,paste(a,"Res.txt",sep=""),sep=" ",row.names=F,quote=F)

rate1=read.table(paste("rate1",a,".txt",sep=""),header=T, sep=" ")
title=read.csv('title.csv',header=T)
r1=merge(rate1,title,by="tconst",all=F)
write.table(r1,paste("rate",a,".txt",sep=""),row.names=F,quote=F)

rate2=read.table(paste("rate2",a,".txt",sep=""),header=T, sep=" ")
rate3=read.table(paste("rate3",a,".txt",sep=""),header=T, sep=" ")
r2=merge(rate2,title,by="tconst",all=F)
r3=merge(rate3,title,by="tconst",all=F)
write.table(r2,paste("rate",a,".txt",sep=""),row.names=F,quote=F,col.names=F,append=T)
write.table(r3,paste("rate",a,".txt",sep=""),row.names=F,quote=F,col.names=F,append=T)

