#!/bin/bash

#wget https://datasets.imdbws.com/name.basics.tsv.gz
#wget https://datasets.imdbws.com/title.akas.tsv.gz
#wget https://datasets.imdbws.com/title.basics.tsv.gz
#wget https://datasets.imdbws.com/title.crew.tsv.gz
#wget https://datasets.imdbws.com/title.episode.tsv.gz
#wget https://datasets.imdbws.com/title.principals.tsv.gz
#wget https://datasets.imdbws.com/title.ratings.tsv.gz

#gzip -d name.basics.tsv.gz
#gzip -d title.akas.tsv.gz
#gzip -d title.basics.tsv.gz
#gzip -d title.crew.tsv.gz
#gzip -d title.episode.tsv.gz
#gzip -d title.principals.tsv.gz
#gzip -d title.ratings.tsv.gz

#cat name.basics.tsv | tr "\\t" "," > name.basics.csv
#cat title.akas.tsv | tr "\\t" "," > title.akas.csv
#cat title.basics.tsv | tr "\\t" "," > title.basics.csv
#cat title.crew.tsv | tr "\\t" "," > title.crew.csv
#cat title.episode.tsv | tr "\\t" "," > title.episode.csv
#cat title.principals.tsv | tr "\\t" "," > title.principals.csv
#cat title.ratings.tsv | tr "\\t" "," > title.ratings.csv

#rm -f *.tsv

echo "tconst,nconst" >> director.csv
cat title.principals.csv | awk -F, '{ if ($4 == "director") {print $0} }' | cut -d, -f1,3 | sort | uniq >> director.csv
echo "tconst,nconst" >> producer.csv
cat title.principals.csv | awk -F, '{ if ($4 == "producer") {print $0} }' | cut -d, -f1,3 | sort | uniq >> producer.csv
echo "tconst,nconst" >> actor.csv
cat title.principals.csv | awk -F, '{ if ($4 == "actor") {print $0} }' | cut -d, -f1,3 | sort | uniq >> actor.csv
echo "tconst,nconst" >> composer.csv
cat title.principals.csv | awk -F, '{ if ($4 == "composer") {print $0} }' | cut -d, -f1,3 | sort | uniq >> composer.csv
echo "tconst,nconst" >> actress.csv
cat title.principals.csv | awk -F, '{ if ($4 == "actress") {print $0} }' | cut -d, -f1,3 | sort | uniq >> actress.csv


#cat title.ratings.csv | cut -d, -f1,2 > ratings.csv
cat title.ratings.csv | uniq > ratings.csv
cat name.basics.csv | cut -d, -f1,2 | sort | uniq > people.csv
cat title.basics.csv | cut -d, -f1,2,3 | uniq > title.csv
